# React + Vite

npm i

npm run dev